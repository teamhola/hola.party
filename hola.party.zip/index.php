<?php
define('APP_DIR', realpath('./'));
require(APP_DIR.'/protected/lib/speed.php');