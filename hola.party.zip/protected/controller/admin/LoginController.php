<?php
class LoginController extends BaseController{
	function actionIndex(){
		echo "hello login!";
	}

	function actionTest(){
		echo "hello login test";
	}
}