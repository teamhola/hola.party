<?php
class MainController extends BaseController{
	function actionIndex(){
		echo "hello admin!";
	}

	function actionTest(){
		echo "hello admin test";
	}
}