<?php
class JumpController extends BaseController {
	// 首页
	function actionIndex(){
		header("Location: https://www.ihola.one"); 
	}
}