<?php
class User extends Model{
	public $table_name = "test_user";
}